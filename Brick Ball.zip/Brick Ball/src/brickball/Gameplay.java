package brickball;

import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.Rectangle;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;

import javax.swing.JPanel;
import javax.swing.Timer;

public class Gameplay extends JPanel implements KeyListener,ActionListener  {

	private boolean play = false;
	private int score = 0;
	private int hiscore = 0 ;

	private int totalBricks = 27;
	private Timer timer;
	private int delay = 8;
	private int playerX = 310;
	
	private int ballposX =120;
	private int ballposY = 350;
	private int ballXdir =-1;
	private int ballYdir=-2;
	private MapGenerator map;
	
	
	public Gameplay(){
		map = new MapGenerator(3,9);
		addKeyListener(this);
		setFocusable(true);
		setFocusTraversalKeysEnabled(false);
		
		timer = new Timer(delay,this);
		timer.start();
		
	}
	
	public void paint(Graphics g){
		//background
		g.setColor(Color.black);
		g.fillRect(1, 1,745, 592);
		
		//the drawing map
		map.draw((Graphics2D)g);
		
		//Border
		g.setColor(Color.yellow);
		g.fillRect(0, 0, 5, 592);
		g.fillRect(0, 0, 740, 5);
		g.fillRect(740,0,5,592);
		  
		//score
		g.setColor(Color.blue);
		g.setFont(new Font("serif",Font.BOLD,25));
		g.drawString(""+score,650,30);
		
		//the paddle
		g.setColor(Color.green);
		g.fillRect(playerX, 550, 150,10);
		
		//the ball
		g.setColor(Color.orange);
		g.fillOval(ballposX, ballposY, 20, 20);
		
		
		//high score
	   

		g.setColor(Color.red);
		g.setFont(new Font("serif",Font.PLAIN,25));
	    g.drawString(""+hiscore,10,30);
	    if(score > hiscore)
		{
			hiscore=score;
		}
		else
			{hiscore=hiscore;}
		
		
		
		if(totalBricks<=0){
			g.clearRect(10, 10, 750, 600);
			g.setColor(Color.cyan);
			g.fillRect(1, 1,740, 592);
		    
			
			
			play = false;
			ballXdir = 0;
			ballYdir = 0;
			
			g.setColor(Color.red);
			g.setFont(new Font("serif",Font.PLAIN,25));
			g.drawString("High Score :"+hiscore,10,30);
			if(score < hiscore)
			{
				hiscore=score;
			}
			else
				{hiscore=hiscore;}
			
			
			g.setColor(Color.magenta);
			g.setFont(new Font("serif",Font.BOLD,40));
			g.drawString("YOU WON",270,200);
			
			g.setColor(Color.orange);
			g.setFont(new Font("serif",Font.BOLD,25));
			g.drawString("Score:"+score,300,280);
			
			g.setColor(Color.blue);
			g.setFont(new Font("serif",Font.PLAIN,30));
			g.drawString("Press Enter to Restart",240,400);
			
			
		}
		
		if(ballposY > 560){
			
			g.clearRect(10, 10, 750, 600);
			g.setColor(Color.cyan);
			g.fillRect(1, 1,740,600);
		    
			play = false;
			ballXdir = 0;
			ballYdir = 0;
			
		   
			g.setColor(Color.blue);
			g.setFont(new Font("serif",Font.BOLD,25));
			g.drawString("High Score :"+hiscore,10,30);
			
			if(score < hiscore)
			{
				hiscore=score;
			}
			else
				{hiscore=hiscore;}
			
			g.setColor(Color.red);
			g.setFont(new Font("serif",Font.BOLD,40));
			g.drawString("Game Over",270,200);
			
			g.setColor(Color.black);
			g.setFont(new Font("serif",Font.BOLD,25));
			g.drawString("Score:"+score,320,280);
			
			g.setColor(Color.blue);
			g.setFont(new Font("serif",Font.BOLD,30));
			g.drawString("Press Enter to Restart",240,400);
			
			
		}
		
		    g.dispose();
		
	
	
	}
	
	@Override
	public void actionPerformed(ActionEvent arg0) {
		timer.start();
		if(play){
			if(new Rectangle(ballposX, ballposY, 20, 20).intersects(new Rectangle(playerX, 550, 150, 8)))
			{
				ballYdir = -ballYdir;
			}
			A:for(int i=0 ; i<map.map.length ; i++){
				for(int j=0 ; j<map.map[0].length; j++)
			{
				if(map.map[i][j]>0)
				{
					int brickX=j*map.brickWidth+80;
					int brickY=i*map.brickWidth+50;
					int brickWidth = map.brickWidth;
					int brickHeight = map.brickHeight;
					
					Rectangle rect = new Rectangle(brickX,brickY,brickWidth,brickHeight);
					
					Rectangle ballRect = new Rectangle(ballposX,ballposY,20,20);

					Rectangle brickRect = rect;
					
					
					if(ballRect.intersects(brickRect))
					{
						map.setBrickValue(0,i,j);
						totalBricks--;
						score+=5;
						
						if(ballposX+19 <= brickRect.x || ballposX+1 >= brickRect.x + brickRect.width){
							ballXdir=-ballYdir;
						}
						else
						{
							ballYdir=-ballYdir;
						}
						break A;
					}
					
				}
			}
				}
			
			
			ballposX +=ballXdir;
			ballposY +=ballYdir;
			if(ballposX < 0)
			{
				ballXdir = -ballXdir;
			}
			if(ballposY < 0)
			{
				ballYdir = -ballYdir;
			}
			if(ballposX > 720)
			{
				ballXdir = -ballXdir;
			}
		}
		
		repaint();
		
	}
	
	@Override
	public void keyReleased(KeyEvent arg0) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void keyTyped(KeyEvent arg0) {
		// TODO Auto-generated method stub
		
	}


	@Override
	public void keyPressed(KeyEvent arg0) {	
		
		if(arg0.getKeyCode() == KeyEvent.VK_RIGHT){
			if(playerX >=590){
			   playerX=590;
			}
			else
			{
				moveRight();
			}
			
		}
        
        	if(arg0.getKeyCode() == KeyEvent.VK_LEFT){
    			if(playerX <=6){
    			   playerX=6;
    			}
    			else
    			{
    				moveLeft();
    				}
    			}
        	if(arg0.getKeyCode()==KeyEvent.VK_ENTER)
        	{
        		if(!play)
        		{
        			play = true;
        			ballposX = 120;
        			ballposY = 350;
        			ballXdir = -1;
        			ballYdir =-2;
        			playerX =310;
        			score = 0;
        		    delay = 8;

        			totalBricks =27;
        			
        			map=new MapGenerator(3,9);
        			repaint();
        		}
        	}
	}
	
	 public void moveRight()
	 {
		play = true;
		playerX+=30 ;
	 }
	 
	 public void moveLeft()
	 {
		play = true;
		playerX-=30 ;
	 }
	
}
